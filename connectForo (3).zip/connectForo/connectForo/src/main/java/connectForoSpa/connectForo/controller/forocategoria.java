package connectForoSpa.connectForo.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class forocategoria {
    @GetMapping("/hola")
    public String holajiles(){
        return("Colo Colo lo mas grande de Chile");
    }

}
