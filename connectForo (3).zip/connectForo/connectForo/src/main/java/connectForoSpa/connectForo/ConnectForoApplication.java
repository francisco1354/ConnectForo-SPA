package connectForoSpa.connectForo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConnectForoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConnectForoApplication.class, args);
	}

}
